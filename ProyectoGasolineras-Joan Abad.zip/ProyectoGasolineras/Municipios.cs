﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProyectoGasolineras
{
    class Municipios
    {
        public string IDMunicipio { get; set; }
        public string IDProvincia { get; set; }
        public string IDCCAA { get; set; }
        public string Municipio { get; set; }
        public string Provincia { get; set; }
        public string CCAA { get; set; }
    }
}
