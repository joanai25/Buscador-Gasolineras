﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProyectoGasolineras
{
    class Provincias
    {
        public string IDPovincia { get; set; }
        public string IDCCAA { get; set; }
        public string Provincia { get; set; }
        public string CCAA { get; set; }
    }
}
