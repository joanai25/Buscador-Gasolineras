﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProyectoGasolineras
{
    class Comunidad
    {
        public string IDCCAA { get; set; }
        public string CCAA { get; set; }
    }
}
